int b = 3; 

int just_a_random_func(int a) {
    return a + b;
}
