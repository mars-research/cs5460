int b = 3, c = 4, d;

int quadruple(int a) {
    return a * c + b * d;
}

int magic() {
    return 14 * b;
}