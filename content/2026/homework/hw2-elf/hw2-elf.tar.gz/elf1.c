int b = 3, c = 4, d;

int linear_transform(int a) {
    return a * c + b * d;
}